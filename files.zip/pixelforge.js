// ============================================================
// PIXELFORGE — Main JavaScript Entry Point
// ============================================================

// ─── DATA ───────────────────────────────────────────────────

const DATA = {
  business: {
    name: "PixelForge",
    tagline: "Websites Crafted for $100",
    email: "stefangodinez@gmail.com",
    phone: "630-914-0386",
    location: "Illinois",
    price: 100,
  },

  steps: [
    {
      num: "01",
      title: "Reach Out",
      desc: "Send us a message with your business name, what you do, and what you're looking for. We get back to you fast.",
    },
    {
      num: "02",
      title: "We Build It",
      desc: "We design and develop your custom website — clean, mobile-friendly, and built to represent your brand.",
    },
    {
      num: "03",
      title: "You Go Live",
      desc: "Review, approve, and launch. A professional online presence without the big price tag.",
    },
  ],

  features: [
    { icon: "📱", title: "Mobile Responsive", desc: "Looks sharp on every device — phones, tablets, and desktops." },
    { icon: "⚡", title: "Fast Loading", desc: "Lightweight, optimized code so visitors don't wait around." },
    { icon: "🎨", title: "Custom Design", desc: "Not a template. Tailored to match your brand and personality." },
    { icon: "🔍", title: "SEO Ready", desc: "Proper structure so Google can find and rank your business." },
    { icon: "📞", title: "Contact Section", desc: "Every site includes a contact area so customers can reach you." },
    { icon: "✏️", title: "Revisions Included", desc: "We tweak until it's exactly what you envisioned." },
  ],

  pricing: [
    "Custom designed website",
    "Mobile-friendly & responsive",
    "Up to 5 pages",
    "Contact section",
    "SEO-friendly structure",
    "Fast turnaround",
    "Revisions until you're happy",
  ],

  marqueeItems: [
    "Professional Websites",
    "$100 Flat Rate",
    "Fast Turnaround",
    "Mobile Friendly",
    "Built for You",
    "No Hidden Fees",
  ],
};

// ─── UTILITIES ───────────────────────────────────────────────

const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function el(tag, attrs = {}, ...children) {
  const elem = document.createElement(tag);
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === "class") elem.className = v;
    else if (k === "html") elem.innerHTML = v;
    else if (k.startsWith("on")) elem.addEventListener(k.slice(2), v);
    else elem.setAttribute(k, v);
  });
  children.flat().forEach((child) => {
    if (typeof child === "string") elem.insertAdjacentHTML("beforeend", child);
    else if (child) elem.appendChild(child);
  });
  return elem;
}

// ─── CURSOR ─────────────────────────────────────────────────

class Cursor {
  constructor() {
    this.dot = el("div", { class: "cursor", id: "cursor" });
    document.body.appendChild(this.dot);
    this.bind();
  }
  bind() {
    document.addEventListener("mousemove", (e) => {
      this.dot.style.left = e.clientX + "px";
      this.dot.style.top = e.clientY + "px";
    });
    document.addEventListener("mouseover", (e) => {
      if (e.target.closest("a, button, .step, .feature-card")) {
        this.dot.classList.add("expand");
      } else {
        this.dot.classList.remove("expand");
      }
    });
  }
}

// ─── NAV ─────────────────────────────────────────────────────

class Nav {
  constructor() {
    this.nav = el(
      "nav",
      {},
      el("a", { class: "logo", href: "#" },
        el("span", {}, DATA.business.name.slice(0, 5)),
        DATA.business.name.slice(5)
      ),
      el("a", { class: "nav-cta", href: "#contact" }, "Get Your Site →")
    );
    document.body.appendChild(this.nav);
  }
}

// ─── HERO ────────────────────────────────────────────────────

class Hero {
  constructor() {
    this.section = el(
      "section",
      { id: "hero" },
      el("p", { class: "hero-eyebrow" }, "Web Design · Built Fast · Priced Right"),
      el(
        "h1",
        { class: "hero-title" },
        `Your<br><span class="line2">Business</span><br><span class="line3">Online.</span>`
      ),
      el(
        "p",
        { class: "hero-sub" },
        "We build clean, professional websites for local businesses, freelancers, and startups. No bloated packages. No hidden fees. Just results."
      ),
      el(
        "a",
        { class: "hero-price-tag", href: "#contact" },
        el("span", { class: "price" }, `$${DATA.business.price}`),
        el("span", { class: "price-label" }, "flat rate<br>per website")
      ),
      el("div", { class: "scroll-hint" }, "Scroll")
    );
    document.body.appendChild(this.section);
  }
}

// ─── MARQUEE ─────────────────────────────────────────────────

class Marquee {
  constructor() {
    const items = [...DATA.marqueeItems, ...DATA.marqueeItems];
    const track = el(
      "div",
      { class: "marquee-track" },
      ...items.flatMap((text) => [
        el("span", {}, text),
        el("span", { class: "dot" }),
      ])
    );
    this.wrap = el("div", { class: "marquee-wrap" }, track);
    document.body.appendChild(this.wrap);
  }
}

// ─── HOW IT WORKS ────────────────────────────────────────────

class HowSection {
  constructor() {
    const steps = DATA.steps.map((s, i) =>
      el(
        "div",
        { class: `step reveal reveal-delay-${i + 1}` },
        el("div", { class: "step-num" }, s.num),
        el("h3", {}, s.title),
        el("p", {}, s.desc),
        el("div", { class: "step-accent-bar" })
      )
    );

    this.section = el(
      "section",
      { id: "how" },
      el("p", { class: "section-label reveal" }, "How It Works"),
      el("h2", { class: "section-title reveal" }, "Three steps.<br>One great site."),
      el("div", { class: "steps" }, ...steps)
    );
    document.body.appendChild(this.section);
  }
}

// ─── FEATURES ────────────────────────────────────────────────

class FeaturesSection {
  constructor() {
    const cards = DATA.features.map((f, i) =>
      el(
        "div",
        { class: `feature-card reveal reveal-delay-${(i % 4) + 1}` },
        el("div", { class: "feature-icon" }, f.icon),
        el("h3", {}, f.title),
        el("p", {}, f.desc)
      )
    );

    this.section = el(
      "section",
      { id: "features" },
      el("p", { class: "section-label reveal" }, "What's Included"),
      el("h2", { class: "section-title reveal" }, "Everything you need.<br>Nothing you don't."),
      el("div", { class: "features-grid" }, ...cards)
    );
    document.body.appendChild(this.section);
  }
}

// ─── PRICING ─────────────────────────────────────────────────

class PricingSection {
  constructor() {
    const listItems = DATA.pricing.map((item) => el("li", {}, item));

    const card = el(
      "div",
      { class: "price-card" },
      el("div", { class: "price-badge" }, "⭐ Our Only Plan"),
      el("div", { class: "price-amount" }, `$${DATA.business.price}`),
      el("p", { class: "price-per" }, "One-time flat rate · Per website"),
      el("ul", { class: "price-includes" }, ...listItems)
    );

    this.section = el(
      "section",
      { id: "pricing" },
      el("p", { class: "section-label reveal" }, "Pricing"),
      el("h2", { class: "section-title reveal" }, "No subscriptions.<br>No surprises."),
      el("div", { class: "reveal" }, card)
    );
    document.body.appendChild(this.section);
  }
}

// ─── CONTACT ─────────────────────────────────────────────────

class ContactSection {
  constructor() {
    // Contact info side
    const info = el(
      "div",
      { class: "contact-info" },
      el("p", { class: "section-label reveal" }, "Contact"),
      el("h2", { class: "section-title reveal" }, "Let's build<br>your site."),
      el("p", { class: "contact-blurb reveal" },
        "Ready to get online? Fill out the form or reach out directly. We respond quickly and make the process painless."
      ),
      el("a", { class: "contact-item reveal", href: `mailto:${DATA.business.email}` },
        el("div", { class: "contact-item-icon" }, "✉"),
        DATA.business.email
      ),
      el("a", { class: "contact-item reveal", href: `tel:${DATA.business.phone.replace(/-/g, "")}` },
        el("div", { class: "contact-item-icon" }, "📞"),
        DATA.business.phone
      )
    );

    // Form side
    this.nameInput = el("input", { type: "text", placeholder: "Jane Smith" });
    this.emailInput = el("input", { type: "email", placeholder: "jane@yourbusiness.com" });
    this.bizInput = el("input", { type: "text", placeholder: "Smith's Plumbing LLC" });
    this.msgInput = el("textarea", { placeholder: "What kind of website do you need?" });
    this.submitBtn = el("button", { class: "form-submit", onclick: () => this.handleSubmit() }, "Send My Request →");

    const form = el(
      "div",
      { class: "contact-form reveal" },
      el("div", { class: "form-group" }, el("label", {}, "Your Name"), this.nameInput),
      el("div", { class: "form-group" }, el("label", {}, "Email"), this.emailInput),
      el("div", { class: "form-group" }, el("label", {}, "Business Name"), this.bizInput),
      el("div", { class: "form-group" }, el("label", {}, "Tell Us About Your Project"), this.msgInput),
      this.submitBtn,
      el("p", { class: "form-note" }, "We'll get back to you within 24 hours.")
    );

    this.section = el(
      "section",
      { id: "contact" },
      el("div", { class: "contact-layout" }, info, form)
    );
    document.body.appendChild(this.section);
  }

  handleSubmit() {
    const name = this.nameInput.value.trim();
    const email = this.emailInput.value.trim();

    if (!name || !email) {
      this.submitBtn.style.background = "#c0392b";
      this.submitBtn.textContent = "Please fill in your name & email!";
      setTimeout(() => {
        this.submitBtn.style.background = "";
        this.submitBtn.textContent = "Send My Request →";
      }, 2500);
      return;
    }

    this.submitBtn.style.background = "#2ecc71";
    this.submitBtn.textContent = "✓ Request Sent! We'll be in touch.";
    this.submitBtn.disabled = true;
  }
}

// ─── FOOTER ──────────────────────────────────────────────────

class Footer {
  constructor() {
    this.footer = el(
      "footer",
      {},
      el("div", { class: "foot-logo" },
        el("span", {}, DATA.business.name.slice(0, 5)),
        DATA.business.name.slice(5)
      ),
      el("p", {}, `© ${new Date().getFullYear()} ${DATA.business.name}. All rights reserved.`),
      el("p", {}, `Made with ⚡ in ${DATA.business.location}`)
    );
    document.body.appendChild(this.footer);
  }
}

// ─── SCROLL REVEAL ───────────────────────────────────────────

class ScrollReveal {
  constructor() {
    this.observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add("visible");
        });
      },
      { threshold: 0.12 }
    );
  }

  observe() {
    $$(".reveal").forEach((el) => this.observer.observe(el));
  }
}

// ─── STYLES ──────────────────────────────────────────────────

function injectStyles() {
  const style = document.createElement("style");
  style.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,wght@0,300;0,400;0,600;1,300&display=swap');

    :root {
      --black: #0a0a0a; --white: #f5f2eb; --accent: #ff5c1a; --gold: #e8c840; --mid: #1c1c1c;
    }
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html { scroll-behavior: smooth; }
    body { background: var(--black); color: var(--white); font-family: 'DM Sans', sans-serif; overflow-x: hidden; cursor: none; }

    .cursor { position: fixed; width: 16px; height: 16px; background: var(--accent); border-radius: 50%; pointer-events: none; z-index: 9999; transform: translate(-50%,-50%); transition: width .2s, height .2s, opacity .2s; mix-blend-mode: difference; }
    .cursor.expand { width: 48px; height: 48px; opacity: .6; }

    body::before { content:''; position:fixed; inset:0; background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E"); pointer-events:none; z-index:9998; opacity:.4; }

    nav { position:fixed; top:0; left:0; right:0; z-index:100; display:flex; justify-content:space-between; align-items:center; padding:1.5rem 3rem; }
    nav::after { content:''; position:absolute; inset:0; background:linear-gradient(to bottom,rgba(10,10,10,.9),transparent); z-index:-1; }
    .logo { font-family:'Bebas Neue',sans-serif; font-size:2rem; letter-spacing:.08em; color:var(--white); text-decoration:none; }
    .logo span { color:var(--accent); }
    .nav-cta { background:var(--accent); color:var(--black); font-weight:600; font-size:.85rem; letter-spacing:.12em; text-transform:uppercase; text-decoration:none; padding:.65rem 1.6rem; border-radius:2px; transition:background .2s,transform .2s; }
    .nav-cta:hover { background:var(--gold); color:var(--black); transform:translateY(-2px); }

    #hero { min-height:100vh; display:flex; flex-direction:column; justify-content:center; padding:8rem 3rem 4rem; position:relative; overflow:hidden; }
    #hero::before { content:'$'; position:absolute; right:-2rem; top:50%; transform:translateY(-50%); font-family:'Bebas Neue',sans-serif; font-size:60vw; color:rgba(255,255,255,.025); line-height:1; pointer-events:none; user-select:none; }

    .hero-eyebrow { font-size:.78rem; letter-spacing:.3em; text-transform:uppercase; color:var(--accent); margin-bottom:1.5rem; opacity:0; animation:fadeUp .7s .2s forwards; }
    .hero-title { font-family:'Bebas Neue',sans-serif; font-size:clamp(5rem,14vw,14rem); line-height:.92; letter-spacing:-.01em; opacity:0; animation:fadeUp .8s .4s forwards; }
    .hero-title .line2 { color:var(--accent); }
    .hero-title .line3 { -webkit-text-stroke:1.5px var(--white); color:transparent; }
    .hero-sub { max-width:480px; font-size:1.1rem; font-weight:300; line-height:1.7; margin-top:2.5rem; color:rgba(245,242,235,.7); opacity:0; animation:fadeUp .8s .6s forwards; }
    .hero-price-tag { display:inline-flex; align-items:baseline; gap:.3rem; margin-top:3rem; background:var(--gold); color:var(--black); padding:1rem 2rem; border-radius:2px; opacity:0; animation:fadeUp .8s .8s forwards; text-decoration:none; transition:all .2s; }
    .hero-price-tag:hover { background:var(--accent); color:var(--white); transform:scale(1.03); }
    .hero-price-tag .price { font-family:'Bebas Neue',sans-serif; font-size:3.5rem; line-height:1; }
    .hero-price-tag .price-label { font-size:.75rem; font-weight:600; letter-spacing:.15em; text-transform:uppercase; }
    .scroll-hint { position:absolute; bottom:2.5rem; left:50%; transform:translateX(-50%); display:flex; flex-direction:column; align-items:center; gap:.5rem; font-size:.7rem; letter-spacing:.2em; text-transform:uppercase; color:rgba(255,255,255,.3); opacity:0; animation:fadeUp 1s 1.2s forwards; }
    .scroll-hint::after { content:''; display:block; width:1px; height:60px; background:linear-gradient(to bottom,rgba(255,255,255,.3),transparent); animation:scrollLine 1.5s 1.5s infinite; }

    .marquee-wrap { background:var(--accent); color:var(--black); padding:1rem 0; overflow:hidden; white-space:nowrap; }
    .marquee-track { display:inline-block; animation:marquee 18s linear infinite; }
    .marquee-track span { font-family:'Bebas Neue',sans-serif; font-size:1.5rem; letter-spacing:.15em; padding:0 2.5rem; }
    .marquee-track .dot { display:inline-block; width:8px; height:8px; background:var(--black); border-radius:50%; vertical-align:middle; margin:0 1rem; }

    section { padding:7rem 3rem; }
    .section-label { font-size:.72rem; letter-spacing:.35em; text-transform:uppercase; color:var(--accent); margin-bottom:1rem; }
    .section-title { font-family:'Bebas Neue',sans-serif; font-size:clamp(3rem,6vw,5.5rem); line-height:1; margin-bottom:1.5rem; }

    #how { background:var(--mid); }
    .steps { display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:2px; margin-top:4rem; }
    .step { background:var(--black); padding:3rem 2rem; position:relative; overflow:hidden; transition:background .3s; }
    .step:hover { background:#111; }
    .step-num { font-family:'Bebas Neue',sans-serif; font-size:5rem; color:rgba(255,255,255,.06); line-height:1; margin-bottom:1rem; transition:color .3s; }
    .step:hover .step-num { color:var(--accent); opacity:.2; }
    .step h3 { font-family:'Bebas Neue',sans-serif; font-size:1.6rem; letter-spacing:.05em; margin-bottom:.75rem; }
    .step p { font-size:.95rem; font-weight:300; color:rgba(245,242,235,.6); line-height:1.65; }
    .step-accent-bar { position:absolute; bottom:0; left:0; height:3px; width:0; background:var(--accent); transition:width .4s ease; }
    .step:hover .step-accent-bar { width:100%; }

    #features { background:var(--black); }
    .features-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:1.5rem; margin-top:4rem; }
    .feature-card { border:1px solid rgba(255,255,255,.08); padding:2.5rem; border-radius:2px; position:relative; overflow:hidden; transition:border-color .3s,transform .3s; }
    .feature-card::before { content:''; position:absolute; top:0; left:0; width:100%; height:100%; background:radial-gradient(circle at 0% 0%,rgba(255,92,26,.08),transparent 60%); opacity:0; transition:opacity .4s; }
    .feature-card:hover { border-color:var(--accent); transform:translateY(-4px); }
    .feature-card:hover::before { opacity:1; }
    .feature-icon { font-size:2rem; margin-bottom:1.2rem; }
    .feature-card h3 { font-family:'Bebas Neue',sans-serif; font-size:1.4rem; letter-spacing:.04em; margin-bottom:.6rem; }
    .feature-card p { font-size:.92rem; font-weight:300; color:rgba(245,242,235,.6); line-height:1.65; }

    #pricing { background:var(--mid); text-align:center; }
    .price-card { display:inline-block; background:var(--black); border:2px solid var(--gold); padding:4rem 5rem; border-radius:4px; margin-top:3rem; position:relative; }
    .price-badge { position:absolute; top:-1.1rem; left:50%; transform:translateX(-50%); background:var(--gold); color:var(--black); font-size:.72rem; font-weight:700; letter-spacing:.2em; text-transform:uppercase; padding:.35rem 1.2rem; border-radius:2px; white-space:nowrap; }
    .price-amount { font-family:'Bebas Neue',sans-serif; font-size:8rem; line-height:1; color:var(--gold); }
    .price-per { font-size:1rem; color:rgba(245,242,235,.5); margin-top:.5rem; letter-spacing:.1em; }
    .price-includes { list-style:none; margin-top:2.5rem; text-align:left; }
    .price-includes li { padding:.75rem 0; border-bottom:1px solid rgba(255,255,255,.07); font-size:.95rem; font-weight:300; display:flex; align-items:center; gap:.75rem; }
    .price-includes li::before { content:'✓'; color:var(--gold); font-weight:700; font-size:.9rem; }

    #contact { background:var(--black); position:relative; overflow:hidden; }
    #contact::before { content:'GET\\ASTARTED'; white-space:pre; position:absolute; right:-1rem; top:50%; transform:translateY(-50%); font-family:'Bebas Neue',sans-serif; font-size:22vw; line-height:.88; color:rgba(255,255,255,.02); pointer-events:none; user-select:none; }
    .contact-layout { display:grid; grid-template-columns:1fr 1fr; gap:6rem; align-items:start; }
    .contact-info,.contact-form { position:relative; z-index:1; }
    .contact-blurb { font-size:1rem; font-weight:300; color:rgba(245,242,235,.65); line-height:1.8; margin-bottom:3rem; }
    .contact-item { display:flex; align-items:center; gap:1rem; margin-bottom:1.5rem; text-decoration:none; color:var(--white); transition:color .2s; font-size:1.05rem; }
    .contact-item:hover { color:var(--accent); }
    .contact-item-icon { width:44px; height:44px; border:1px solid rgba(255,255,255,.15); border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0; transition:border-color .2s,background .2s; }
    .contact-item:hover .contact-item-icon { border-color:var(--accent); background:var(--accent); }
    .form-group { margin-bottom:1.25rem; }
    .form-group label { display:block; font-size:.72rem; letter-spacing:.2em; text-transform:uppercase; color:rgba(245,242,235,.4); margin-bottom:.5rem; }
    .form-group input, .form-group textarea { width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.1); color:var(--white); font-family:'DM Sans',sans-serif; font-size:1rem; padding:1rem 1.25rem; border-radius:2px; outline:none; transition:border-color .2s,background .2s; }
    .form-group input:focus, .form-group textarea:focus { border-color:var(--accent); background:rgba(255,92,26,.05); }
    .form-group textarea { resize:vertical; min-height:130px; }
    .form-submit { width:100%; background:var(--accent); color:var(--white); font-family:'DM Sans',sans-serif; font-weight:700; font-size:.85rem; letter-spacing:.18em; text-transform:uppercase; padding:1.2rem; border:none; border-radius:2px; cursor:pointer; transition:background .2s,transform .2s; margin-top:.5rem; }
    .form-submit:hover { background:var(--gold); color:var(--black); transform:translateY(-2px); }
    .form-note { font-size:.78rem; color:rgba(245,242,235,.3); text-align:center; margin-top:1rem; }

    footer { background:#050505; padding:2.5rem 3rem; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem; border-top:1px solid rgba(255,255,255,.06); }
    .foot-logo { font-family:'Bebas Neue',sans-serif; font-size:1.6rem; color:var(--white); }
    .foot-logo span { color:var(--accent); }
    footer p { font-size:.82rem; color:rgba(245,242,235,.3); }

    .reveal { opacity:0; transform:translateY(30px); transition:opacity .7s ease,transform .7s ease; }
    .reveal.visible { opacity:1; transform:none; }
    .reveal-delay-1 { transition-delay:.1s; }
    .reveal-delay-2 { transition-delay:.2s; }
    .reveal-delay-3 { transition-delay:.3s; }
    .reveal-delay-4 { transition-delay:.4s; }

    @keyframes fadeUp { from{opacity:0;transform:translateY(28px)} to{opacity:1;transform:translateY(0)} }
    @keyframes marquee { from{transform:translateX(0)} to{transform:translateX(-50%)} }
    @keyframes scrollLine { 0%{transform:scaleY(0);transform-origin:top} 50%{transform:scaleY(1);transform-origin:top} 51%{transform:scaleY(1);transform-origin:bottom} 100%{transform:scaleY(0);transform-origin:bottom} }

    @media(max-width:768px){ .contact-layout{grid-template-columns:1fr;gap:3rem} }
    @media(max-width:600px){ nav{padding:1.2rem 1.5rem} #hero{padding:7rem 1.5rem 3rem} section{padding:5rem 1.5rem} footer{padding:2rem 1.5rem} .price-card{padding:3rem 2rem} .price-amount{font-size:5rem} }
  `;
  document.head.appendChild(style);
}

// ─── APP INIT ────────────────────────────────────────────────

class App {
  init() {
    injectStyles();

    // Set page title & meta
    document.title = `${DATA.business.name} — ${DATA.business.tagline}`;
    const meta = document.createElement("meta");
    meta.name = "viewport";
    meta.content = "width=device-width, initial-scale=1.0";
    document.head.appendChild(meta);

    // Build components
    new Cursor();
    new Nav();
    new Hero();
    new Marquee();
    new HowSection();
    new FeaturesSection();
    new PricingSection();
    new ContactSection();
    new Footer();

    // Scroll reveal (after DOM is built)
    const reveal = new ScrollReveal();
    reveal.observe();
  }
}

// ─── BOOT ────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", () => new App().init());
